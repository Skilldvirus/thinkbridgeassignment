export class Customer {
  public _id: string;
  public age: number;
  public name: string;
  public address: string;
  public email: string;
  public phone: string;
}
